# AGC Pump.fun Trading Bot

Bot trading otomatis untuk token AGC di Pump.fun dengan fitur:
- Auto buy/sell
- Take profit 30% / stop loss 20%
- Laporan ke file dan Telegram

## Cara Pakai

1. Salin `.env.example` menjadi `.env` dan isi data Anda.
2. Jalankan `npm install`
3. Jalankan `node agc-bot.js`

